package com.example.raiteupap.includes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.raiteupap.R;

public class MyToolbar {

    // Método estático para mostrar la barra de herramientas personalizada
    public static void show(AppCompatActivity activity, String title, boolean upButton){
        // Obtener la referencia a la barra de herramientas desde el diseño de la actividad
        Toolbar toolbar = activity.findViewById(R.id.toolbar);
        // Establecer la barra de herramientas como la barra de soporte de la actividad
        activity.setSupportActionBar(toolbar);
        // Establecer el título de la barra de herramientas
        activity.getSupportActionBar().setTitle(title);
        // Establecer si se debe mostrar el botón de navegación hacia atrás
        activity.getSupportActionBar().setDisplayHomeAsUpEnabled(upButton);
    }
}

