package com.example.raiteupap.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.raiteupap.R;
import com.example.raiteupap.activities.client.MapClientActivity;
import com.example.raiteupap.activities.driver.MapDriverActivity;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    Button mButtonUser; // Botón para usuario
    Button mButtonDriver; // Botón para conductor

    SharedPreferences mPref; // Preferencias compartidas para almacenar el tipo de usuario

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Obtener las preferencias compartidas
        mPref = getApplicationContext().getSharedPreferences("typeUser", MODE_PRIVATE);
        final SharedPreferences.Editor editor = mPref.edit();

        // Inicialización de vistas
        mButtonUser = findViewById(R.id.btnClient);
        mButtonDriver = findViewById(R.id.btnDriver);

        // Configuración del clic del botón de usuario
        mButtonUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putString("user", "client"); // Almacenar el tipo de usuario como "client"
                editor.apply(); // Aplicar los cambios en las preferencias compartidas
                goToSelectAuth(); // Ir a la pantalla de selección de autenticación
            }
        });

        // Configuración del clic del botón de conductor
        mButtonDriver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putString("user", "driver"); // Almacenar el tipo de usuario como "driver"
                editor.apply(); // Aplicar los cambios en las preferencias compartidas
                goToSelectAuth(); // Ir a la pantalla de selección de autenticación
            }
        });
    }

    @Override
    protected void onStart(){
        super.onStart();

        // Verificar si hay un usuario actualmente autenticado
        if(FirebaseAuth.getInstance().getCurrentUser() != null){
            String user = mPref.getString("user", ""); // Obtener el tipo de usuario de las preferencias compartidas
            if(user.equals("client")){ // Si el usuario es un cliente
                // Redirigir a la actividad del cliente (MapClientActivity)
                Intent intent = new Intent(MainActivity.this , MapClientActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            } else { // Si el usuario es un conductor
                // Redirigir a la actividad del conductor (MapDriverActivity)
                Intent intent = new Intent(MainActivity.this , MapDriverActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        }
    }

    // Método para ir a la pantalla de selección de autenticación
    private void goToSelectAuth() {
        Intent intent = new Intent(MainActivity.this, SelectOptionAuthActivity.class);
        startActivity(intent);
    }
}
