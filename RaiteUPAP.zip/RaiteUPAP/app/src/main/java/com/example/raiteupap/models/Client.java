package com.example.raiteupap.models;

public class Client {

    // Atributos de la clase
    String id; // Identificador único del cliente
    String name; // Nombre del cliente
    String matricula; // Matrícula del cliente
    String email; // Correo electrónico del cliente

    // Constructor de la clase
    public Client(String id, String name, String matricula, String email) {
        this.id = id;
        this.name = name;
        this.matricula = matricula;
        this.email = email;
    }

    // Métodos para acceder y modificar los atributos (getters y setters)

    // Método getter para obtener el ID del cliente
    public String getId() {
        return id;
    }

    // Método setter para establecer el ID del cliente
    public void setId(String id) {
        this.id = id;
    }

    // Método getter para obtener el nombre del cliente
    public String getName() {
        return name;
    }

    // Método setter para establecer el nombre del cliente
    public void setName(String name) {
        this.name = name;
    }

    // Método getter para obtener la matrícula del cliente
    public String getMatricula() {
        return matricula;
    }

    // Método setter para establecer la matrícula del cliente
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    // Método getter para obtener el correo electrónico del cliente
    public String getEmail() {
        return email;
    }

    // Método setter para establecer el correo electrónico del cliente
    public void setEmail(String email) {
        this.email = email;
    }
}
