package com.example.raiteupap.activities.client;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.raiteupap.R;
import com.example.raiteupap.includes.MyToolbar;
import com.example.raiteupap.models.Client;
import com.example.raiteupap.providers.AuthProvider;
import com.example.raiteupap.providers.ClientProvider;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import dmax.dialog.SpotsDialog;

public class RegisterActivity extends AppCompatActivity {

    AuthProvider mAuthProvider; // Proveedor de autenticación para gestionar la autenticación del usuario
    ClientProvider mClientProvider; // Proveedor de cliente para gestionar la creación de clientes
    //Views
    Button mButtonRegister; // Botón de registro
    TextInputEditText mTextInputName; // Campo de entrada de nombre
    TextInputEditText mTextInputMatricula; // Campo de entrada de matrícula
    TextInputEditText mTextInputEmail; // Campo de entrada de correo electrónico
    TextInputEditText mTextInputPassword; // Campo de entrada de contraseña
    AlertDialog mDialog; // Diálogo de espera mientras se procesa la operación de registro

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        MyToolbar.show(this, "Registrar un nuevo usuario", true); // Mostrar la barra de herramientas personalizada

        mAuthProvider = new AuthProvider(); // Inicializar el proveedor de autenticación
        mClientProvider = new ClientProvider(); // Inicializar el proveedor de cliente

        mDialog = new SpotsDialog.Builder().setContext(RegisterActivity.this).setMessage("Espere un momento").build(); // Crear un diálogo de espera

        // Obtener referencias a las vistas desde el diseño de la actividad
        mButtonRegister = findViewById(R.id.btnRegister);
        mTextInputEmail = findViewById(R.id.textInputEmail);
        mTextInputMatricula = findViewById(R.id.textInputMatricula);
        mTextInputName = findViewById(R.id.textInputName);
        mTextInputPassword = findViewById(R.id.textInputPassword);

        // Configurar un OnClickListener para el botón de registro
        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickRegister(); // Método para manejar el clic en el botón de registro
            }
        });
    }

    // Método para manejar el clic en el botón de registro
    void clickRegister() {
        // Obtener los valores ingresados en los campos de entrada
        final String name = mTextInputName.getText().toString();
        final String matricula = mTextInputMatricula.getText().toString();
        final String email = mTextInputEmail.getText().toString();
        final String password = mTextInputPassword.getText().toString();

        // Verificar que todos los campos estén completos
        if (!name.isEmpty() && !matricula.isEmpty() && !email.isEmpty() && !password.isEmpty()) {
            // Verificar que la contraseña tenga al menos 6 caracteres
            if (password.length() >= 6) {
                mDialog.show(); // Mostrar el diálogo de espera
                register(name, matricula, email, password); // Método para registrar al usuario
            } else {
                Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show(); // Mostrar mensaje de error
            }
        } else {
            Toast.makeText(this, "Ingrese todos los campos", Toast.LENGTH_SHORT).show(); // Mostrar mensaje de error
        }
    }

    // Método para registrar al usuario en Firebase Authentication
    void register(final String name, final String matricula, final String email, String password) {
        mAuthProvider.register(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                mDialog.hide(); // Ocultar el diálogo de espera
                if (task.isSuccessful()) { // Si el registro fue exitoso
                    String id = FirebaseAuth.getInstance().getCurrentUser().getUid(); // Obtener el ID del usuario registrado
                    Client client = new Client(id, name, matricula, email); // Crear un objeto Client con la información del usuario
                    create(client); // Método para crear el usuario en la base de datos
                } else {
                    Toast.makeText(RegisterActivity.this, "No se pudo registrar el usuario", Toast.LENGTH_SHORT).show(); // Mostrar mensaje de error
                }
            }
        });
    }

    // Método para crear el usuario en la base de datos
    void create(Client client) {
        mClientProvider.create(client).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) { // Si la creación del usuario fue exitosa
                    //Toast.makeText(RegisterActivity.this, "El registro se realizó correctamente", Toast.LENGTH_SHORT).show(); // Mostrar mensaje de éxito
                    Intent intent = new Intent(RegisterActivity.this, MapClientActivity.class); // Crear un intent para abrir la actividad MapClientActivity
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Limpiar la pila de actividades
                    startActivity(intent); // Iniciar la actividad MapClientActivity
                } else {
                    Toast.makeText(RegisterActivity.this, "No se pudo crear el usuario", Toast.LENGTH_SHORT).show(); // Mostrar mensaje de error
                }
            }
        });
    }

/*
    void  saveUser(String id, String name, String matricula, String email){
        String selectedUser = mPref.getString("user", "");
        User user = new User();
        user.setEmail(email);
        user.setName(name);
        user.setMatricula(matricula);
        if(selectedUser.equals("driver")){
            mDatabase.child("Users").child("Drivers").child(id).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>(){
                @Override
                public void onComplete(@NonNull Task<Void> task){
                    if(task.isSuccessful()){
                        Toast.makeText(RegisterActivity.this,"Registro exitoso", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(RegisterActivity.this,"Falló el registro", Toast.LENGTH_SHORT).show();

                    }

                }
            });

        }
        else if(selectedUser.equals("client")) {
            mDatabase.child("Users").child("Clients").child(id).setValue(user).addOnCompleteListener(new OnCompleteListener<Void>(){
                @Override
                public void onComplete(@NonNull Task<Void> task){
                    if(task.isSuccessful()){
                        Toast.makeText(RegisterActivity.this,"Registro exitoso", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(RegisterActivity.this,"Falló el registro", Toast.LENGTH_SHORT).show();

                    }

                }
            });

        }
        }

 */
    }
