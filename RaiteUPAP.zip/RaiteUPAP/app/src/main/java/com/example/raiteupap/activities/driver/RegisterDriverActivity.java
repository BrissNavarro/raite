package com.example.raiteupap.activities.driver;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.raiteupap.R;
import com.example.raiteupap.includes.MyToolbar;
import com.example.raiteupap.models.Driver;
import com.example.raiteupap.providers.AuthProvider;
import com.example.raiteupap.providers.DriverProvider;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import dmax.dialog.SpotsDialog;

public class RegisterDriverActivity extends AppCompatActivity {

    // Proveedores de autenticación y de conductor
    AuthProvider mAuthProvider;
    DriverProvider mDriverProvider;

    // Views
    Button mButtonRegister;
    TextInputEditText mTextInputName;
    TextInputEditText mTextInputMatricula;
    TextInputEditText mTextInputEmail;
    TextInputEditText mTextInputPassword;
    TextInputEditText mTextInputVehiclePlate;
    TextInputEditText mTextInputDriverID;
    TextInputEditText mTextInputVehicleBrand;
    TextInputEditText mTextInputSecure;

    // Diálogo de carga
    AlertDialog mDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_driver);

        // Mostrar la barra de herramientas personalizada
        MyToolbar.show(this, "Registrar un nuevo conductor", true);

        // Inicializar proveedores y diálogo de carga
        mAuthProvider = new AuthProvider();
        mDriverProvider = new DriverProvider();
        mDialog = new SpotsDialog.Builder().setContext(RegisterDriverActivity.this).setMessage("Espere un momento").build();

        // Obtener referencias a las vistas
        mButtonRegister = findViewById(R.id.btnRegister);
        mTextInputEmail = findViewById(R.id.textInputEmail);
        mTextInputMatricula = findViewById(R.id.textInputMatricula);
        mTextInputName = findViewById(R.id.textInputName);
        mTextInputPassword = findViewById(R.id.textInputPassword);
        mTextInputVehiclePlate = findViewById(R.id.textInputVehiclePlate);
        mTextInputDriverID = findViewById(R.id.textInputDriverID);
        mTextInputVehicleBrand = findViewById(R.id.textInputVehicleBrand);
        mTextInputSecure = findViewById(R.id.textInputSecure);

        // Establecer el listener para el botón de registro
        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clickRegister();
            }
        });
    }

    // Método para procesar el registro
    void clickRegister() {
        // Obtener los valores de los campos de entrada
        final String name = mTextInputName.getText().toString();
        final String matricula = mTextInputMatricula.getText().toString();
        final String email = mTextInputEmail.getText().toString();
        final String password = mTextInputPassword.getText().toString();
        final String vehiclePlate = mTextInputVehiclePlate.getText().toString();
        final String vehicleBrand = mTextInputVehicleBrand.getText().toString();
        final String driverID = mTextInputDriverID.getText().toString();
        final String secure = mTextInputSecure.getText().toString();

        // Verificar que todos los campos estén completos
        if (!name.isEmpty() && !matricula.isEmpty() && !email.isEmpty() && !password.isEmpty() && !vehiclePlate.isEmpty() && !vehicleBrand.isEmpty() && !driverID.isEmpty() && !secure.isEmpty()) {
            // Verificar que la contraseña tenga al menos 6 caracteres
            if (password.length() >= 6) {
                // Mostrar el diálogo de carga y realizar el registro
                mDialog.show();
                register(name, matricula, email, password, vehicleBrand, vehiclePlate, driverID, secure);
            } else {
                // Mostrar un mensaje de error si la contraseña es demasiado corta
                Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Mostrar un mensaje de error si no se completaron todos los campos
            Toast.makeText(this, "Ingrese todos los campos", Toast.LENGTH_SHORT).show();
        }
    }

    // Método para realizar el registro de usuario
    void register(final String name, final String matricula, final String email, String password, final String vehicleBrand, final String vehiclePlate, final String driverID, final String secure) {
        mAuthProvider.register(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                mDialog.hide();
                if (task.isSuccessful()) {
                    // Obtener el ID del usuario registrado y crear un objeto Driver
                    String id = FirebaseAuth.getInstance().getCurrentUser().getUid();
                    Driver driver = new Driver(id, name, matricula, email, vehicleBrand, vehiclePlate, driverID, secure);
                    // Crear el registro del conductor en la base de datos
                    create(driver);
                } else {
                    // Mostrar un mensaje de error si el registro falla
                    Toast.makeText(RegisterDriverActivity.this, "No se pudo registrar el usuario", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Método para crear el registro del conductor en la base de datos
    void create(Driver driver){
        mDriverProvider.create(driver).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    // Mostrar un mensaje de éxito y dirigir al usuario a la actividad de mapa del conductor
                    Toast.makeText(RegisterDriverActivity.this, "El registro se realizó correctamente", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(RegisterDriverActivity.this , MapDriverActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                } else {
                    // Mostrar un mensaje de error si la creación del registro falla
                    Toast.makeText(RegisterDriverActivity.this,"No se pudo crear el usuario", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}

