package com.example.raiteupap.activities.client;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.raiteupap.R;
import com.example.raiteupap.activities.MainActivity;
import com.example.raiteupap.providers.AuthProvider;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

public class MapClientActivity extends AppCompatActivity implements OnMapReadyCallback {

    AuthProvider mAuthProvider; // Proveedor de autenticación para gestionar la autenticación del usuario
    private GoogleMap mMap; // Referencia al objeto GoogleMap
    private SupportMapFragment mMapFragment; // Fragmento de mapa utilizado para mostrar el mapa

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_client);

        mAuthProvider = new AuthProvider(); // Inicializar el proveedor de autenticación

        // Obtener el fragmento de mapa desde el diseño de la actividad
        mMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        // Obtener de manera asincrónica una instancia de GoogleMap y llamar a onMapReady una vez que esté listo
        mMapFragment.getMapAsync(this);
    }

    // Método llamado cuando el mapa está listo para ser utilizado
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap; // Asignar el objeto GoogleMap para su uso posterior
        mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL); // Establecer el tipo de mapa (normal)
    }

    // Método para inflar el menú en la barra de herramientas
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.driver_menu, menu); // Inflar el menú desde el archivo XML
        return super.onCreateOptionsMenu(menu);
    }

    // Método que maneja los clics en los elementos del menú
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.action_logout) { // Si se hace clic en el elemento de menú de cierre de sesión
            logout(); // Cerrar sesión
        }
        return super.onOptionsItemSelected(item);
    }

    // Método para cerrar sesión del usuario actual
    void logout() {
        mAuthProvider.logout(); // Llamar al método logout del proveedor de autenticación para cerrar sesión
        Intent intent = new Intent(MapClientActivity.this, MainActivity.class); // Crear un intent para abrir la actividad principal
        startActivity(intent); // Iniciar la actividad principal
        finish(); // Finalizar la actividad actual
    }
}

