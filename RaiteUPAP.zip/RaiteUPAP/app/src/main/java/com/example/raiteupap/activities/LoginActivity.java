package com.example.raiteupap.activities;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.raiteupap.R;
import com.example.raiteupap.activities.client.MapClientActivity;
import com.example.raiteupap.activities.driver.MapDriverActivity;
import com.example.raiteupap.includes.MyToolbar;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import dmax.dialog.SpotsDialog;

public class LoginActivity extends AppCompatActivity {

    TextInputEditText mTextInputEmail; // Campo de entrada para el correo electrónico del usuario
    TextInputEditText mTextInputPassword; // Campo de entrada para la contraseña del usuario
    Button mButtonLogin; // Botón para iniciar sesión

    FirebaseAuth mAuth; // Instancia de FirebaseAuth para autenticación
    DatabaseReference mDatabase; // Referencia a la base de datos de Firebase

    AlertDialog mDialog; // Diálogo de progreso para mostrar mientras se realiza la autenticación
    SharedPreferences mPref; // Preferencias compartidas para almacenar el tipo de usuario

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        MyToolbar.show(this, "Login usuario", true); // Mostrar la barra de herramientas personalizada

        // Inicialización de vistas
        mTextInputEmail = findViewById(R.id.textInputEmail);
        mTextInputPassword = findViewById(R.id.textInputPassword);
        mButtonLogin = findViewById(R.id.btnLogin);

        // Inicialización de FirebaseAuth y la base de datos
        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Inicialización del diálogo de progreso
        mDialog = new SpotsDialog.Builder().setContext(LoginActivity.this).setMessage("Espere un momento").build();

        // Obtener las preferencias compartidas
        mPref = getApplicationContext().getSharedPreferences("typeUser", MODE_PRIVATE);

        // Configurar el clic del botón de inicio de sesión
        mButtonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                login(); // Iniciar el proceso de inicio de sesión
            }
        });
    }

    // Método para realizar el inicio de sesión
    private void login() {
        String email = mTextInputEmail.getText().toString();
        String password = mTextInputPassword.getText().toString();

        // Verificar que el email y la contraseña no estén vacíos
        if (!email.isEmpty() && !password.isEmpty()) {
            // Verificar que la contraseña tenga al menos 6 caracteres
            if (password.length() >= 6) {
                mDialog.show(); // Mostrar el diálogo de progreso

                // Iniciar sesión con el email y la contraseña proporcionados
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) { // Si el inicio de sesión es exitoso
                            String user = mPref.getString("user", ""); // Obtener el tipo de usuario de las preferencias compartidas
                            if (user.equals("client")) { // Si el usuario es un cliente
                                // Redirigir a la actividad del cliente (MapClientActivity)
                                Intent intent = new Intent(LoginActivity.this, MapClientActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            } else { // Si el usuario es un conductor
                                // Redirigir a la actividad del conductor (MapDriverActivity)
                                Intent intent = new Intent(LoginActivity.this, MapDriverActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        } else { // Si el inicio de sesión falla
                            Toast.makeText(LoginActivity.this, "El email o el password son incorrectos", Toast.LENGTH_SHORT).show();
                        }
                        mDialog.dismiss(); // Ocultar el diálogo de progreso
                    }
                });
            }
        } else { // Si el email o la contraseña están vacíos
            Toast.makeText(this, "La contraseña y el email son obligatorios", Toast.LENGTH_SHORT).show();
        }
    }
}
