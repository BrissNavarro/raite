package com.example.raiteupap.models;

public class User {

    String id;
    String name;
    String matricula;
    String email;

    public User() {

    }

    public User(String id, String name, String matricula, String email) {
        this.id = id;
        this.name = name;
        this.matricula = matricula;
        this.email = email;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}