package com.example.raiteupap.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.raiteupap.R;
import com.example.raiteupap.activities.client.RegisterActivity;
import com.example.raiteupap.activities.driver.RegisterDriverActivity;
import com.example.raiteupap.includes.MyToolbar;

public class SelectOptionAuthActivity extends AppCompatActivity {

    Button mButtonGoToLogin; // Botón para ir a la pantalla de inicio de sesión
    Button mButtonGoToRegister; // Botón para ir a la pantalla de registro
    SharedPreferences mPref; // Preferencias compartidas para almacenar el tipo de usuario

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_option_auth);
        MyToolbar.show(this, "Seleccione una opción", true); // Mostrar la barra de herramientas personalizada

        // Inicialización de vistas
        mButtonGoToLogin = findViewById(R.id.btnGoToLogin);
        mButtonGoToRegister = findViewById(R.id.btnGoToRegister);

        // Configuración del clic del botón para ir a la pantalla de inicio de sesión
        mButtonGoToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToLogin();
            }
        });

        // Configuración del clic del botón para ir a la pantalla de registro
        mButtonGoToRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goToRegister();
            }
        });

        // Obtener las preferencias compartidas
        mPref = getApplicationContext().getSharedPreferences("typeUser", MODE_PRIVATE);
    }

    // Método para ir a la pantalla de inicio de sesión
    public void goToLogin() {
        Intent intent = new Intent(SelectOptionAuthActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    // Método para ir a la pantalla de registro dependiendo del tipo de usuario seleccionado
    public void goToRegister() {
        String typeUser = mPref.getString("user", ""); // Obtener el tipo de usuario de las preferencias compartidas
        if (typeUser.equals("client")) { // Si el usuario es un cliente
            Intent intent = new Intent(SelectOptionAuthActivity.this, RegisterActivity.class); // Ir a la actividad de registro de cliente
            startActivity(intent);
        } else { // Si el usuario es un conductor
            Intent intent = new Intent(SelectOptionAuthActivity.this, RegisterDriverActivity.class); // Ir a la actividad de registro de conductor
            startActivity(intent);
        }
    }
}
